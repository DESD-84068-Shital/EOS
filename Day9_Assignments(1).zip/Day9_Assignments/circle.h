#ifndef CIRCLE_H
#define CIRCLE_H

float calculateCircleArea(float radius);

#endif
