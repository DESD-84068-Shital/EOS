#include "rectnagle.h"

float calculateRectangleArea(float length, float width) {
    return length * width;
}
