#ifndef RECTANGLE_H
#define RECTANGLE_H

float calculateRectangleArea(float length, float width);

#endif
