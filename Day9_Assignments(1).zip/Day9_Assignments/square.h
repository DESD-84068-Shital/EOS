#ifndef SQUARE_H
#define SQUARE_H

float calculateSquareArea(float side);

#endif
