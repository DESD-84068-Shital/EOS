#include "square.h"

float calculateSquareArea(float side) {
    return side * side;
}
