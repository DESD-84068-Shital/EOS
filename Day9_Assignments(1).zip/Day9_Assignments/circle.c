#include"circle.h"

double circle_area(double r)
{
 return 3.142 * r * r;
}
